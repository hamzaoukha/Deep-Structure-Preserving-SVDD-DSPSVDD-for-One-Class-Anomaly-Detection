# Deployment

## GitHub Pages (Docs)
- Ensure GitHub Actions are enabled.
- Push to `main`. The workflow `.github/workflows/pages.yml` builds and deploys MkDocs.

## Streamlit Cloud (App)
- Create a new Streamlit app from this repo.
- Set the entry point to `src/apps/streamlit_app.py`.
- Add any required secrets under Streamlit settings (if needed).
