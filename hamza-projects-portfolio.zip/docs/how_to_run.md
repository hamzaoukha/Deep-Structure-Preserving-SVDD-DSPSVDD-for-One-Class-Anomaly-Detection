# How to Run

## Local
```bash
conda env create -f environment.yml
conda activate hamza-ml
streamlit run src/apps/streamlit_app.py
```

## Colab
1. Mount Google Drive.
2. Ensure datasets under `/content/drive/MyDrive/Master/data/...`.
3. Open `notebooks/*.py` (jupytext) in Colab, run all.
