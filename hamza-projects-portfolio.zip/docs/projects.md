# Projects

- **Tifinagh MLP**: From-scratch PyTorch MLP for character classification.
- **DSPSVDD**: Deep anomaly detection experiments (Colab-ready scaffold).
- **Transfer Learning (PyTorch)**: Clean training loop and configs.
- **Streamlit Demo**: Interactive app for quick demos to your professor.
- **Reports (LaTeX IMRAD)**: Polished, publication-style write-ups.
