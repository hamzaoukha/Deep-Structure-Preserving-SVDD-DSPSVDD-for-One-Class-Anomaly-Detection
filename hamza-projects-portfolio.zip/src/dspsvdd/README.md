# DSPSVDD Notes

Place your DSPSVDD code here (e.g., training loops, loss functions).  
Link: `notebooks/DSPSVDD_colab.py` for a Colab-friendly pipeline using jupytext.
