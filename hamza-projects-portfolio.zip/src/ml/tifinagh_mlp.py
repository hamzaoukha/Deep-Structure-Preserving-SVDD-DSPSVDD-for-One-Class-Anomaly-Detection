import torch
import torch.nn as nn
import torch.nn.functional as F

class TifinaghMLP(nn.Module):
    def __init__(self, in_dim=32*32, num_classes=33, hidden=(512, 256), dropout=0.2):
        super().__init__()
        dims = [in_dim, *hidden]
        layers = []
        for i in range(len(dims)-1):
            layers += [nn.Linear(dims[i], dims[i+1]), nn.ReLU(), nn.Dropout(dropout)]
        self.backbone = nn.Sequential(*layers)
        self.head = nn.Linear(dims[-1], num_classes)

    def forward(self, x):
        # x: (B, in_dim)
        z = self.backbone(x)
        return self.head(z)
