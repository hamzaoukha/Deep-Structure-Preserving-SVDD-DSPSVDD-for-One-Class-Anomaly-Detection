import streamlit as st
import numpy as np
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

st.set_page_config(page_title="Hamza Portfolio", page_icon="✅")

st.title("Hamza Projects — Streamlit Demo")
st.markdown("This app showcases a tiny ML demo and links to docs.")

with st.expander("Digits Classifier (quick demo)"):
    digits = load_digits()
    X = digits.data
    y = digits.target
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = LogisticRegression(max_iter=2000, n_jobs=None)
    clf.fit(X_train, y_train)
    preds = clf.predict(X_test)
    acc = accuracy_score(y_test, preds)
    st.write(f"Test accuracy: **{acc:.3f}** on scikit-learn digits dataset.")

    idx = st.slider("Pick a test sample", 0, len(X_test)-1, 0)
    sample = X_test[idx]
    pred = clf.predict([sample])[0]
    st.write(f"Prediction: **{pred}** (true: {y_test[idx]})")
    st.image(sample.reshape(8,8), caption="8x8 Digit", width=128, clamp=True)

st.markdown("---")
st.write("📚 **Docs**: Once deployed to GitHub Pages, your site will appear here.")
st.write("🧠 **Projects**: See repo folders for ML code, notebooks, and LaTeX reports.")
