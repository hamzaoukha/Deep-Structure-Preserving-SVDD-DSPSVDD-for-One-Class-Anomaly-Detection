#!/usr/bin/env bash
set -e
streamlit run src/apps/streamlit_app.py
