# Changelog

## [1.0.0] - 2025-08-30
- Initial release of the portfolio monorepo template.
