# %% [markdown]
# # Transfer Learning (PyTorch) — Colab (Jupytext .py)
# Ensure data under `/content/drive/MyDrive/Master/data/...`

# %%
import os, time
import torch
import torch.nn as nn
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Device:", device)

# TODO: set dataset path
data_dir = "/content/drive/MyDrive/Master/data/your_dataset"
train_tfms = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
])

train_ds = datasets.ImageFolder(os.path.join(data_dir, "train"), transform=train_tfms)
val_ds   = datasets.ImageFolder(os.path.join(data_dir, "val"), transform=train_tfms)

train_dl = DataLoader(train_ds, batch_size=32, shuffle=True, num_workers=2)
val_dl   = DataLoader(val_ds, batch_size=32, shuffle=False, num_workers=2)

model = models.resnet18(weights="IMAGENET1K_V1")
model.fc = nn.Linear(model.fc.in_features, len(train_ds.classes))
model.to(device)

# TODO: optimizer/loss/train loop
print("Scaffold ready — plug your loop.")
