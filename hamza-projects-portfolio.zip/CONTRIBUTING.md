# Contributing

1. Fork & create a feature branch.
2. Run `pytest` locally.
3. Submit a PR with a clear description and screenshots (if UI-related).
