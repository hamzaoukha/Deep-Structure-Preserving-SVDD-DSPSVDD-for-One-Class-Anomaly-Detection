def test_imports():
    import numpy, pandas, sklearn, matplotlib, torch  # noqa: F401
